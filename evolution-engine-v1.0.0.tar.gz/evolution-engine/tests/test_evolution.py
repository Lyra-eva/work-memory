#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Evolution Engine - 测试用例
"""

import sys
import os

# 添加核心模块到路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'core'))

def test_imports():
    """测试模块导入"""
    print("\n[1] 测试模块导入")
    try:
        from evolution import (
            EvolutionEventBus,
            EvolutionPipeline,
            PatternMiner,
            EvolutionValidator,
            EvolutionEvent,
            EvolutionEventType,
            create_event,
            enable_auto_trigger,
        )
        print("   ✅ 所有模块导入成功")
        return True
    except Exception as e:
        print(f"   ❌ 模块导入失败：{e}")
        return False

def test_event_bus():
    """测试事件总线"""
    print("\n[2] 测试事件总线")
    try:
        from evolution import EvolutionEventBus, create_event, EvolutionEventType
        
        bus = EvolutionEventBus()
        event = create_event(
            EvolutionEventType.CAPABILITY_LEARNED,
            'test',
            {'test': 'installation'},
            importance=0.5
        )
        event_id = bus.publish(event)
        
        history = bus.get_event_history(agent_id='test', limit=1)
        
        print(f"   ✅ 事件发布成功 (ID: {event_id})")
        print(f"   ✅ 历史查询成功 ({len(history)} 条记录)")
        return True
    except Exception as e:
        print(f"   ❌ 事件总线测试失败：{e}")
        return False

def test_pipeline():
    """测试进化流水线"""
    print("\n[3] 测试进化流水线")
    try:
        from evolution import EvolutionPipeline, create_event, EvolutionEventType
        
        pipeline = EvolutionPipeline(agent_id='test')
        event = create_event(
            EvolutionEventType.CAPABILITY_LEARNED,
            'test',
            {'capability': 'test', 'success': True},
            importance=0.7
        )
        result = pipeline.execute_pipeline(event)
        
        print(f"   ✅ 流水线执行完成 (状态：{result.status})")
        return True
    except Exception as e:
        print(f"   ❌ 流水线测试失败：{e}")
        return False

def test_pattern_miner():
    """测试模式挖掘"""
    print("\n[4] 测试模式挖掘")
    try:
        from evolution import PatternMiner
        
        miner = PatternMiner(agent_id='test')
        patterns = miner.mine()
        
        print(f"   ✅ 模式挖掘完成 ({len(patterns['patterns'])} 个模式)")
        return True
    except Exception as e:
        print(f"   ❌ 模式挖掘测试失败：{e}")
        return False

def test_validator():
    """测试验证器"""
    print("\n[5] 测试验证器")
    try:
        from evolution import EvolutionValidator
        
        validator = EvolutionValidator()
        capability = {
            'id': 'test.test.1.0.0',
            'name': 'test',
            'version': '1.0.0',
            'owner_agent': 'test',
            'interface_schema': {'inputs': [], 'outputs': []}
        }
        result = validator.validate_capability(capability)
        
        print(f"   ✅ 能力验证完成 (得分：{result.score:.0f}/100)")
        return True
    except Exception as e:
        print(f"   ❌ 验证器测试失败：{e}")
        return False

def test_auto_trigger():
    """测试自动触发器"""
    print("\n[6] 测试自动触发器")
    try:
        from evolution import enable_auto_trigger
        
        auto_trigger = enable_auto_trigger(agent_id='test')
        stats = auto_trigger.get_stats()
        
        print(f"   ✅ 自动触发器已启用")
        print(f"      配置：{auto_trigger.config.to_dict()}")
        return True
    except Exception as e:
        print(f"   ❌ 自动触发器测试失败：{e}")
        return False

def main():
    """运行所有测试"""
    print("=" * 60)
    print("🧪 Evolution Engine - 安装验证测试")
    print("=" * 60)
    
    tests = [
        test_imports,
        test_event_bus,
        test_pipeline,
        test_pattern_miner,
        test_validator,
        test_auto_trigger,
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            if test():
                passed += 1
            else:
                failed += 1
        except Exception as e:
            print(f"   ❌ 测试异常：{e}")
            failed += 1
    
    print("\n" + "=" * 60)
    print(f"测试结果：{passed} 通过，{failed} 失败")
    print("=" * 60)
    
    if failed == 0:
        print("\n✅ 所有测试通过！安装成功！")
        return 0
    else:
        print(f"\n❌ {failed} 个测试失败")
        return 1

if __name__ == '__main__':
    sys.exit(main())
