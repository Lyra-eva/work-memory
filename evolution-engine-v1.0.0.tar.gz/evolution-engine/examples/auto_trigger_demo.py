#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Evolution Engine - 自动触发器示例
"""

import sys
import os
import time

# 添加核心模块到路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'core'))

from evolution import (
    EvolutionEventBus,
    enable_auto_trigger,
    create_event,
    EvolutionEventType,
)

def main():
    print("=" * 60)
    print("🚀 Evolution Engine - 自动触发器示例")
    print("=" * 60)
    
    # 1. 启用自动触发器
    print("\n[1] 启用自动触发器")
    auto_trigger = enable_auto_trigger(agent_id='lily')
    print("   ✓ 自动触发器已启用")
    print(f"      配置：{auto_trigger.config.to_dict()}")
    
    # 2. 创建事件总线
    print("\n[2] 创建事件总线")
    bus = EvolutionEventBus()
    print("   ✓ 事件总线已创建")
    
    # 3. 发布事件（会自动触发流水线！）
    print("\n[3] 发布事件（会自动触发流水线）")
    event = create_event(
        EvolutionEventType.CAPABILITY_LEARNED,
        'lily',
        {
            'capability': 'auto_test',
            'success': True,
            'latency': 45
        },
        importance=0.85  # 高重要性，会触发模式挖掘
    )
    
    print("   发布事件...")
    event_id = bus.publish(event)
    print(f"   ✓ 事件已发布 (ID: {event_id})")
    
    # 等待自动触发完成
    print("\n   等待自动触发...")
    time.sleep(1)
    
    # 4. 查看统计
    print("\n[4] 查看统计")
    stats = auto_trigger.get_stats()
    print(f"   ✓ 统计信息:")
    print(f"      流水线执行：{stats['pipeline_executions']} 次")
    print(f"      模式挖掘：{stats['pattern_mining_runs']} 次")
    print(f"      最后触发：{stats.get('last_trigger_time', 'N/A')}")
    
    # 5. 查看日志
    print("\n[5] 查看日志")
    log = auto_trigger.get_log(lines=5)
    print("   最近日志:")
    for line in log[-3:]:
        print(f"      {line.strip()}")
    
    # 6. 手动触发（可选）
    print("\n[6] 手动触发测试")
    result = auto_trigger.trigger_pipeline(event)
    print(f"   ✓ 手动触发完成")
    print(f"      状态：{result['status']}")
    print(f"      阶段：{result['stage']}")
    
    print("\n" + "=" * 60)
    print("✅ 示例运行完成")
    print("=" * 60)
    print("\n💡 提示:")
    print("   • 自动触发器会在能力学习后自动执行流水线")
    print("   • 高重要性事件（>=0.8）会自动触发模式挖掘")
    print("   • 可以通过 configure() 调整配置")
    print("   • 日志文件位置：~/.openclaw/workspace/memory/evolution/auto_trigger.log")

if __name__ == '__main__':
    main()
