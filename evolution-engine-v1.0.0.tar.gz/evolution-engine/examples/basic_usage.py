#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Evolution Engine - 基础使用示例
"""

import sys
import os

# 添加核心模块到路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'core'))

from evolution import (
    EvolutionEventBus,
    EvolutionPipeline,
    PatternMiner,
    EvolutionValidator,
    create_event,
    EvolutionEventType,
)

def main():
    print("=" * 60)
    print("🧬 Evolution Engine - 基础使用示例")
    print("=" * 60)
    
    # 1. 创建事件总线
    print("\n[1] 创建事件总线")
    bus = EvolutionEventBus()
    print("   ✓ 事件总线已创建")
    
    # 2. 创建进化事件
    print("\n[2] 创建进化事件")
    event = create_event(
        EvolutionEventType.CAPABILITY_LEARNED,
        'lily',
        {
            'capability': 'web_search',
            'success': True,
            'latency': 50,
            'accuracy': 0.95
        },
        importance=0.8,
        tags=['capability', 'growth']
    )
    print(f"   ✓ 事件已创建：{event.event_type}")
    
    # 3. 发布事件
    print("\n[3] 发布事件")
    event_id = bus.publish(event)
    print(f"   ✓ 事件已发布 (ID: {event_id})")
    
    # 4. 执行进化流水线
    print("\n[4] 执行进化流水线")
    pipeline = EvolutionPipeline(agent_id='lily')
    result = pipeline.execute_pipeline(event)
    print(f"   ✓ 流水线执行完成")
    print(f"      状态：{result.status}")
    print(f"      最终阶段：{result.stage.value}")
    
    # 5. 挖掘进化模式
    print("\n[5] 挖掘进化模式")
    miner = PatternMiner(agent_id='lily')
    patterns = miner.mine()
    print(f"   ✓ 模式挖掘完成")
    print(f"      发现模式：{len(patterns['patterns'])} 个")
    print(f"      生成建议：{len(patterns['recommendations'])} 条")
    
    for i, rec in enumerate(patterns['recommendations'][:3], 1):
        print(f"      [{i}] {rec['title']} (置信度：{rec['confidence']:.0%})")
    
    # 6. 验证能力
    print("\n[6] 验证能力")
    validator = EvolutionValidator()
    capability = {
        'id': 'lily.web_search.1.0.0',
        'name': 'web_search',
        'version': '1.0.0',
        'owner_agent': 'lily',
        'description': 'Web 搜索能力',
        'interface_schema': {
            'inputs': [{'name': 'query', 'type': 'string'}],
            'outputs': [{'name': 'results', 'type': 'list'}]
        }
    }
    result = validator.validate_capability(capability)
    print(f"   ✓ 能力验证完成")
    print(f"      状态：{result.status.value}")
    print(f"      得分：{result.score:.0f}/100")
    
    # 7. 查询历史
    print("\n[7] 查询进化历史")
    history = bus.get_event_history(agent_id='lily', limit=5)
    print(f"   ✓ 查询到 {len(history)} 条记录")
    
    for i, event in enumerate(history[:3], 1):
        print(f"      [{i}] {event.timestamp}: {event.event_type}")
    
    print("\n" + "=" * 60)
    print("✅ 示例运行完成")
    print("=" * 60)

if __name__ == '__main__':
    main()
