#!/bin/bash
# Evolution Engine for OpenClaw - 一键安装脚本

set -e

echo "============================================================"
echo "🧬 Evolution Engine for OpenClaw - 安装脚本"
echo "============================================================"
echo ""

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 获取脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OPENCLAW_DIR="${OPENCLAW_DIR:-$HOME/.openclaw}"
SKILLS_DIR="$OPENCLAW_DIR/workspace/skills"
MEMORY_DIR="$OPENCLAW_DIR/workspace/memory"

echo -e "${YELLOW}📍 安装信息:${NC}"
echo "   脚本目录：$SCRIPT_DIR"
echo "   OpenClaw 目录：$OPENCLAW_DIR"
echo "   技能目录：$SKILLS_DIR"
echo ""

# 检查 Python
echo -e "${YELLOW}[1/6] 检查 Python 环境...${NC}"
if command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version)
    echo -e "   ${GREEN}✓${NC} Python 环境：$PYTHON_VERSION"
else
    echo -e "   ${RED}✗${NC} Python3 未安装"
    exit 1
fi

# 检查 OpenClaw 目录
echo -e "\n${YELLOW}[2/6] 检查 OpenClaw 目录...${NC}"
if [ ! -d "$OPENCLAW_DIR" ]; then
    echo -e "   ${RED}✗${NC} OpenClaw 目录不存在：$OPENCLAW_DIR"
    echo "   请先安装 OpenClaw"
    exit 1
fi
echo -e "   ${GREEN}✓${NC} OpenClaw 目录存在"

# 创建技能目录
echo -e "\n${YELLOW}[3/6] 创建技能目录...${NC}"
mkdir -p "$SKILLS_DIR"
echo -e "   ${GREEN}✓${NC} 技能目录已创建：$SKILLS_DIR"

# 复制核心模块
echo -e "\n${YELLOW}[4/6] 复制核心模块...${NC}"
EVOLUTION_SRC="$SCRIPT_DIR/../core/evolution"
EVOLUTION_DEST="$SKILLS_DIR/evolution"

if [ -d "$EVOLUTION_SRC" ]; then
    # 删除旧版本（如果存在）
    if [ -d "$EVOLUTION_DEST" ]; then
        rm -rf "$EVOLUTION_DEST"
        echo "   已删除旧版本"
    fi
    
    # 复制新版本
    cp -r "$EVOLUTION_SRC" "$EVOLUTION_DEST"
    echo -e "   ${GREEN}✓${NC} 核心模块已复制"
else
    echo -e "   ${RED}✗${NC} 核心模块目录不存在：$EVOLUTION_SRC"
    exit 1
fi

# 创建记忆系统目录
echo -e "\n${YELLOW}[5/6] 创建记忆系统目录...${NC}"
mkdir -p "$MEMORY_DIR/evolution"
mkdir -p "$MEMORY_DIR/capabilities"

# 初始化事件文件
if [ ! -f "$MEMORY_DIR/evolution/events.jsonl" ]; then
    touch "$MEMORY_DIR/evolution/events.jsonl"
    echo "   已创建 events.jsonl"
fi

if [ ! -f "$MEMORY_DIR/evolution/index.json" ]; then
    echo '{"schema":"evolution.index.v1","events":[],"total_events":0}' > "$MEMORY_DIR/evolution/index.json"
    echo "   已创建 index.json"
fi

if [ ! -f "$MEMORY_DIR/evolution/stats.json" ]; then
    echo '{"schema":"evolution.stats.v1","total_events":0,"by_type":{},"importance_avg":0}' > "$MEMORY_DIR/evolution/stats.json"
    echo "   已创建 stats.json"
fi

echo -e "   ${GREEN}✓${NC} 记忆系统目录已创建"

# 安装 Python 依赖
echo -e "\n${YELLOW}[6/6] 安装 Python 依赖...${NC}"
if [ -f "$SCRIPT_DIR/../requirements.txt" ]; then
    echo "   正在安装依赖..."
    pip3 install -r "$SCRIPT_DIR/../requirements.txt" --user -q
    echo -e "   ${GREEN}✓${NC} 依赖安装完成"
else
    echo -e "   ${YELLOW}⚠${NC} requirements.txt 不存在，跳过依赖安装"
fi

# 验证安装
echo -e "\n${YELLOW}验证安装...${NC}"
cd "$SCRIPT_DIR/.."
if python3 -c "import sys; sys.path.insert(0, 'core'); from evolution import EvolutionEventBus; print('OK')" 2>/dev/null; then
    echo -e "   ${GREEN}✓${NC} 模块导入成功"
else
    echo -e "   ${RED}✗${NC} 模块导入失败"
    exit 1
fi

# 完成
echo -e "\n${GREEN}============================================================"
echo "✅ 安装完成！"
echo -e "============================================================${NC}"
echo ""
echo "📍 安装位置:"
echo "   核心模块：$EVOLUTION_DEST"
echo "   记忆目录：$MEMORY_DIR/evolution"
echo ""
echo "🚀 使用示例:"
echo ""
echo "   python3 -c \""
echo "   from evolution import ("
echo "       EvolutionEventBus,"
echo "       EvolutionPipeline,"
echo "       enable_auto_trigger,"
echo "       create_event,"
echo "       EvolutionEventType"
echo "   )"
echo ""
echo "   # 启用自动触发"
echo "   enable_auto_trigger(agent_id='lily')"
echo ""
echo "   # 发布事件"
echo "   bus = EvolutionEventBus()"
echo "   event = create_event(EvolutionEventType.CAPABILITY_LEARNED, 'lily', {})"
echo "   bus.publish(event)"
echo "   \""
echo ""
echo "📖 文档:"
echo "   README.md - 使用说明"
echo "   docs/ - 详细文档"
echo "   examples/ - 示例代码"
echo ""
echo "============================================================"
