# GitHub 上传指南

## 📋 准备工作

### 1. 创建 GitHub 仓库

1. 访问 https://github.com/new
2. 仓库名称：`evolution-engine`
3. 描述：`🧬 智能体进化引擎 - 让 OpenClaw 智能体自主进化、持续成长`
4. 选择公开仓库（Public）
5. **不要**勾选 "Initialize this repository with a README"
6. 点击 "Create repository"

### 2. 初始化本地 Git

```bash
cd /home/admin/.openclaw/workspace/evolution-engine

# 初始化 Git
git init

# 添加所有文件
git add .

# 提交
git commit -m "Initial commit: Evolution Engine v1.0.0"
```

### 3. 关联远程仓库

```bash
# 添加远程仓库（替换 YOUR_USERNAME 为你的 GitHub 用户名）
git remote add origin https://github.com/YOUR_USERNAME/evolution-engine.git

# 推送到 GitHub
git push -u origin main
```

如果提示分支名称问题：

```bash
# 重命名分支
git branch -M main

# 再次推送
git push -u origin main
```

## 🚀 完整命令

```bash
# 进入项目目录
cd /home/admin/.openclaw/workspace/evolution-engine

# 初始化 Git
git init
git add .
git commit -m "Initial commit: Evolution Engine v1.0.0 🎉"

# 关联远程仓库（替换为你的仓库地址）
git remote add origin https://github.com/openclaw/evolution-engine.git

# 推送
git branch -M main
git push -u origin main
```

## ✅ 验证上传

1. 访问 https://github.com/openclaw/evolution-engine
2. 确认所有文件都已上传
3. 检查 README 是否正确显示

## 📝 后续维护

### 发布新版本

```bash
# 修改 CHANGELOG.md
# 修改 setup.py 版本号

# 提交更改
git add .
git commit -m "Release v1.0.1"

# 打标签
git tag -a v1.0.1 -m "Version 1.0.1"

# 推送
git push origin main
git push origin --tags
```

### 更新 README

```bash
# 编辑 README.md
git add README.md
git commit -m "Update README"
git push
```

## 🏷️ 添加主题标签

在 GitHub 仓库页面：

1. 点击 "Manage topics"
2. 添加标签：
   - `openclaw`
   - `ai`
   - `evolution`
   - `agent`
   - `machine-learning`
   - `python`

## 📊 添加徽章

在 README.md 中添加：

```markdown
[![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)](https://github.com/openclaw/evolution-engine)
[![Python](https://img.shields.io/badge/python-3.6+-green.svg)](https://python.org)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
```

## 🎉 完成

上传完成后：

1. ✅ 检查仓库页面
2. ✅ 测试安装脚本
3. ✅ 分享给社区

---

**祝发布顺利！** 🚀
