# 更新日志

## [1.0.0] - 2026-03-12

### ✨ 新增
- 进化引擎核心功能
  - 事件总线（EvolutionEventBus）
  - 进化流水线（EvolutionPipeline）- 5 阶段自动化
  - 模式挖掘器（PatternMiner）
  - 进化验证器（EvolutionValidator）
- 自动触发器（EvolutionAutoTrigger）
  - 能力学习后自动执行流水线
  - 高重要性事件自动触发模式挖掘
  - 定时任务调度器（EvolutionScheduler）
- 记忆系统集成
  - 事件存储到 JSONL 文件
  - 能力注册到记忆系统
  - 自动索引和统计

### 🔧 优化
- 精简代码，移除冗余功能
- 优化性能，减少内存占用
- 改进模块结构，便于维护

### 📖 文档
- README.md - 使用说明
- AUTO_TRIGGER_GUIDE.md - 自动触发器指南
- 示例代码 - basic_usage.py, auto_trigger_demo.py

### 🧪 测试
- 完整的测试套件
- 安装验证脚本

---

## 版本说明

### v1.0.0 (2026-03-12)
- 初始发布版本
- 基于 evacore-evolution v3.2.0 精简优化
- 支持 Python 3.6+
- 完全兼容 OpenClaw 记忆系统
