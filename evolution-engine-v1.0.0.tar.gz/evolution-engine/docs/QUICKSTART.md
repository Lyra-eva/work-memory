# 快速开始指南

## 📦 安装

### 方法 1: Git 克隆（推荐）

```bash
# 克隆项目
git clone https://github.com/openclaw/evolution-engine.git

# 进入目录
cd evolution-engine

# 运行安装脚本
./scripts/install.sh
```

### 方法 2: 下载 ZIP

1. 下载项目 ZIP 文件
2. 解压到本地
3. 运行 `./scripts/install.sh`

## 🚀 使用

### 基础用法

```python
from evolution import (
    EvolutionEventBus,
    EvolutionPipeline,
    create_event,
    EvolutionEventType
)

# 1. 创建事件总线
bus = EvolutionEventBus()

# 2. 创建进化事件
event = create_event(
    EvolutionEventType.CAPABILITY_LEARNED,
    'lily',
    {'capability': 'web_search', 'success': True},
    importance=0.8
)

# 3. 发布事件
bus.publish(event)

# 4. 执行进化流水线
pipeline = EvolutionPipeline(agent_id='lily')
result = pipeline.execute_pipeline(event)
print(f"进化完成：{result.status}")
```

### 启用自动触发

```python
from evolution import enable_auto_trigger

# 一行代码启用自动触发
auto_trigger = enable_auto_trigger(agent_id='lily')

# 之后发布事件会自动执行流水线！
bus.publish(event)  # 自动触发！
```

## 📖 更多文档

- [README.md](../README.md) - 项目说明
- [API 文档](API.md) - 详细 API
- [示例代码](../examples/) - 使用示例

## 🧪 测试

```bash
# 运行测试
python3 tests/test_evolution.py
```

## ❓ 常见问题

### 安装失败怎么办？

1. 确保 Python 版本 >= 3.6
2. 确保 OpenClaw 已安装
3. 检查依赖：`pip3 install -r requirements.txt`

### 模块导入失败？

确保已运行安装脚本，并且路径正确：
```python
import sys
sys.path.insert(0, '/path/to/openclaw/workspace/skills')
from evolution import ...
```

### 如何启用自动触发？

```python
from evolution import enable_auto_trigger
auto_trigger = enable_auto_trigger(agent_id='lily')
```

## 🤝 获取帮助

- GitHub Issues: [提交问题](https://github.com/openclaw/evolution-engine/issues)
- 查看示例：[examples/](../examples/)
