#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Evolution Engine for OpenClaw - 安装配置
"""

from setuptools import setup, find_packages
from pathlib import Path

# 读取 README
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding='utf-8')

# 读取依赖
requirements = []
if (this_directory / "requirements.txt").exists():
    with open(this_directory / "requirements.txt", 'r', encoding='utf-8') as f:
        requirements = [line.strip() for line in f if line.strip() and not line.startswith('#')]

setup(
    name='evolution-engine',
    version='1.0.0',
    author='OpenClaw Community',
    author_email='support@openclaw.ai',
    description='🧬 智能体进化引擎 - 让 OpenClaw 智能体自主进化、持续成长',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/openclaw/evolution-engine',
    packages=find_packages(where='core'),
    package_dir={'': 'core'},
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
    ],
    python_requires='>=3.6',
    install_requires=requirements,
    entry_points={
        'console_scripts': [
            'evolution-check=scripts.install:check_installation',
        ],
    },
    include_package_data=True,
    zip_safe=False,
)
