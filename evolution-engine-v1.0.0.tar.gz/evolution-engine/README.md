# Evolution Engine for OpenClaw

🧬 **智能体进化引擎** - 让 OpenClaw 智能体自主进化、持续成长

[![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)](https://github.com/openclaw/evolution-engine)
[![Python](https://img.shields.io/badge/python-3.6+-green.svg)](https://python.org)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)

---

## 🎯 功能特性

- 🧠 **自主进化** - 智能体从经验中自主学习进化
- 🔄 **进化流水线** - 5 阶段自动化进化流程
- 📊 **模式挖掘** - 识别个人成长模式，生成进化建议
- ✅ **能力验证** - 确保新能力质量与安全性
- 🚀 **自动触发** - 能力学习后自动执行进化流程
- 💾 **记忆集成** - 与 OpenClaw 记忆系统无缝集成

---

## 🚀 快速开始

### 一键安装

```bash
# 克隆项目
git clone https://github.com/openclaw/evolution-engine.git

# 进入目录
cd evolution-engine

# 运行安装脚本
./install.sh
```

### 使用示例

```python
from evolution import (
    EvolutionEventBus,
    EvolutionPipeline,
    PatternMiner,
    enable_auto_trigger,
    create_event,
    EvolutionEventType
)

# 1. 启用自动触发（可选）
auto_trigger = enable_auto_trigger(agent_id='lily')

# 2. 发布进化事件
bus = EvolutionEventBus()
event = create_event(
    EvolutionEventType.CAPABILITY_LEARNED,
    'lily',
    {'capability': 'web_search', 'success': True},
    importance=0.8
)
bus.publish(event)

# 3. 执行进化流水线（如果启用了自动触发，这步会自动执行）
pipeline = EvolutionPipeline(agent_id='lily')
result = pipeline.execute_pipeline(event)
print(f"进化完成：{result.status}")

# 4. 挖掘进化模式
miner = PatternMiner(agent_id='lily')
patterns = miner.mine()
for rec in patterns['recommendations']:
    print(f"建议：{rec['title']}")
```

---

## 📦 项目结构

```
evolution-engine/
├── core/                        # 核心模块
│   └── evolution/
│       ├── __init__.py          # 统一入口
│       └── engine/
│           ├── __init__.py
│           ├── memory_event_bus.py    # 事件总线
│           ├── evolution_pipeline.py  # 进化流水线
│           └── auto_trigger.py        # 自动触发器
├── tests/                       # 测试用例
│   └── test_evolution.py
├── examples/                    # 使用示例
│   ├── basic_usage.py
│   └── auto_trigger_demo.py
├── scripts/                     # 工具脚本
│   └── install.sh
├── docs/                        # 文档
│   ├── API.md
│   └── GUIDE.md
├── requirements.txt             # Python 依赖
├── setup.py                     # 安装配置
├── install.sh                   # 一键安装脚本
├── README.md                    # 使用说明
└── LICENSE                      # 开源协议
```

---

## 📋 安装说明

### 系统要求

- Python 3.6+
- OpenClaw 1.0+
- 操作系统：Linux / macOS

### 安装步骤

#### 方法 1: 一键安装（推荐）

```bash
./install.sh
```

#### 方法 2: 手动安装

```bash
# 1. 安装 Python 依赖
pip3 install -r requirements.txt

# 2. 复制到 OpenClaw 技能目录
cp -r core/evolution /path/to/openclaw/workspace/skills/

# 3. 验证安装
python3 -c "from evolution import EvolutionEventBus; print('✅ 安装成功')"
```

### 验证安装

```bash
python3 tests/test_evolution.py
```

---

## 🔧 配置

### 自动触发器配置

编辑 `~/.openclaw/workspace/memory/evolution/auto_trigger_config.json`:

```json
{
  "enabled": true,
  "auto_execute_pipeline": true,
  "auto_mine_patterns": true,
  "pattern_mining_interval_hours": 1,
  "log_enabled": true
}
```

---

## 📖 文档

- [API 文档](docs/API.md)
- [使用指南](docs/GUIDE.md)
- [自动触发器](docs/AUTO_TRIGGER.md)
- [示例代码](examples/)

---

## 🧪 测试

```bash
# 运行所有测试
python3 -m pytest tests/

# 运行单个测试
python3 tests/test_evolution.py
```

---

## 🤝 贡献

欢迎贡献代码、报告问题或提出建议！

1. Fork 本项目
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启 Pull Request

---

## 📄 开源协议

本项目采用 [MIT](LICENSE) 协议开源。

---

## 🙏 致谢

- OpenClaw 团队
- 所有贡献者

---

## 📬 联系方式

- GitHub Issues: [提交问题](https://github.com/openclaw/evolution-engine/issues)
- 邮箱：support@openclaw.ai

---

**Made with ❤️ for OpenClaw Community**
