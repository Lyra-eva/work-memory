# Stability System for OpenClaw

🛡️ **系统稳定性监控** - Context 监控、超时保护、熔断器、任务分类

[![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)]()
[![Python](https://img.shields.io/badge/python-3.6+-green.svg)]()
[![License](https://img.shields.io/badge/license-MIT-green.svg)]()

---

## 🎯 功能特性

- 📊 **Context 监控** - 监控会话 Context 使用率，三级告警
- ⏱️ **超时保护** - Cron 任务和子任务超时控制
- 🔌 **熔断器** - 工具调用保护和自动恢复
- 🤖 **子任务管理** - 并发控制和资源分配
- 🎯 **任务分类** - 智能分类和资源分配
- ⚡ **性能优化** - 自动检测和调优
- 🏥 **健康监控** - 统一健康检查接口

---

## 🚀 快速开始

### 一键安装

```bash
# 克隆项目
git clone https://github.com/openclaw/stability-system.git

# 进入目录
cd stability-system

# 运行安装脚本
./scripts/install.sh
```

### 使用示例

#### 1. Context 监控

```python
from stability import ContextMonitor

monitor = ContextMonitor()

# 检查使用率
status = monitor.check_usage()
print(f"Context 使用率：{status['avg_usage']:.1%}")

# 清理旧会话
result = monitor.cleanup(keep_recent=10)
print(f"清理了 {result['cleaned']} 个会话")
```

#### 2. 子任务管理

```python
from stability import SubagentManager

manager = SubagentManager(max_concurrent=5)

# 创建任务
task = manager.create_task("web_search", timeout_seconds=60)
manager.start_task(task.task_id)

# 完成任务
manager.complete_task(task.task_id, {"result": "success"})

# 查看统计
stats = manager.get_stats()
print(f"已完成：{stats['completed']} 个任务")
```

#### 3. Cron 超时执行

```python
from stability import CronTimeoutExecutor

cron = CronTimeoutExecutor()

# 添加任务
task = cron.add_task("daily_backup", "0 2 * * *", timeout_seconds=300)

# 执行带超时保护的任务
def backup():
    # 备份逻辑
    pass

result = cron.execute_with_timeout(task.task_id, backup)
print(f"执行成功：{result['success']}")
```

#### 4. 任务分类

```python
from stability import TaskClassifier

classifier = TaskClassifier()

# 分类任务
classification = classifier.classify(
    "web_search",
    "Search for information online"
)

print(f"任务类型：{classification.task_type.value}")
print(f"优先级：{classification.priority}")
print(f"预估时间：{classification.estimated_time}秒")
```

---

## 📦 项目结构

```
stability-system/
├── core/                        # 核心模块
│   └── stability/
│       ├── __init__.py          # 统一入口
│       ├── context_monitor.py   # Context 监控
│       ├── subagent_manager.py  # 子任务管理
│       ├── cron_timeout_executor.py  # Cron 超时
│       ├── task_classifier.py   # 任务分类
│       ├── tool_call_protection.py   # 工具保护
│       ├── health_monitor.py    # 健康监控
│       └── performance_optimizer.py  # 性能优化
├── tests/                       # 测试用例
│   └── test_basic.py
├── examples/                    # 使用示例
│   ├── basic_usage.py
│   └── advanced_usage.py
├── scripts/                     # 工具脚本
│   └── install.sh
├── docs/                        # 文档
│   ├── QUICKSTART.md
│   └── API.md
├── requirements.txt             # Python 依赖
├── setup.py                     # 安装配置
├── install.sh                   # 一键安装脚本
├── README.md                    # 使用说明
└── LICENSE                      # 开源协议
```

---

## 📋 安装说明

### 系统要求

- Python 3.6+
- OpenClaw 1.0+
- 操作系统：Linux / macOS

### 安装步骤

#### 方法 1: 一键安装（推荐）

```bash
./scripts/install.sh
```

#### 方法 2: 手动安装

```bash
# 1. 安装 Python 依赖
pip3 install -r requirements.txt

# 2. 复制到 OpenClaw 技能目录
cp -r core/stability /path/to/openclaw/workspace/skills/

# 3. 验证安装
python3 -c "from stability import ContextMonitor; print('✅ 安装成功')"
```

### 验证安装

```bash
python3 tests/test_basic.py
```

---

## 🔧 配置

### 可选配置

```yaml
# stability_config.yaml
context_monitor:
  max_tokens: 100000
  thresholds:
    warning: 0.5      # 50% 告警
    critical: 0.8     # 80% 限流
    emergency: 0.95   # 95% 强制清理

subagent:
  max_concurrent: 5   # 最大并发数

cron:
  default_timeout: 60  # 默认超时（秒）
  max_retries: 3       # 最大重试次数
```

---

## 🧪 测试

```bash
# 运行所有测试
python3 tests/test_basic.py

# 运行单个测试
python3 -c "from stability import ContextMonitor; m = ContextMonitor(); print(m.check_usage())"
```

---

## 📖 文档

- [快速开始](docs/QUICKSTART.md)
- [API 文档](docs/API.md)
- [使用示例](examples/)

---

## 🤝 贡献

欢迎贡献代码、报告问题或提出建议！

1. Fork 本项目
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启 Pull Request

---

## 📄 开源协议

本项目采用 [MIT](LICENSE) 协议开源。

---

## 🙏 致谢

- OpenClaw 团队
- 所有贡献者

---

## 📬 联系方式

- GitHub Issues: [提交问题](https://github.com/openclaw/stability-system/issues)
- 邮箱：support@openclaw.ai

---

**Made with ❤️ for OpenClaw Community**
