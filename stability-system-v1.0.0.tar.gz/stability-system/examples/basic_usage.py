#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Stability System - 基础使用示例
"""

import sys
import os

# 添加核心模块到路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'core'))

from stability import (
    ContextMonitor,
    SubagentManager,
    CronTimeoutExecutor,
    TaskClassifier,
)

def main():
    print("=" * 60)
    print("🛡️ Stability System - 基础使用示例")
    print("=" * 60)
    
    # 1. Context 监控
    print("\n[1] Context 监控")
    monitor = ContextMonitor()
    status = monitor.get_status()
    usage = monitor.check_usage()
    print(f"   ✓ 最大 tokens: {status['max_tokens']:,}")
    print(f"   ✓ 当前会话：{usage['sessions']} 个")
    print(f"   ✓ 使用率：{usage.get('avg_usage', 0):.1%}")
    
    # 2. 子任务管理
    print("\n[2] 子任务管理")
    manager = SubagentManager(max_concurrent=5)
    task = manager.create_task("web_search", timeout_seconds=60)
    manager.start_task(task.task_id)
    manager.complete_task(task.task_id, {"result": "success"})
    stats = manager.get_stats()
    print(f"   ✓ 创建任务：{task.task_id}")
    print(f"   ✓ 总任务：{stats['total']} 个")
    print(f"   ✓ 已完成：{stats['completed']} 个")
    
    # 3. Cron 超时
    print("\n[3] Cron 超时执行")
    cron = CronTimeoutExecutor()
    task = cron.add_task("test_task", "*/5 * * * *", timeout_seconds=10)
    result = cron.execute_with_timeout(task.task_id, lambda: {"success": True})
    stats = cron.get_stats()
    print(f"   ✓ 添加任务：{task.task_id}")
    print(f"   ✓ 执行结果：{result['success']}")
    print(f"   ✓ 总任务：{stats['total']} 个")
    
    # 4. 任务分类
    print("\n[4] 任务分类")
    classifier = TaskClassifier()
    classification = classifier.classify("web_search", "Search online")
    print(f"   ✓ 任务类型：{classification.task_type.value}")
    print(f"   ✓ 优先级：{classification.priority}")
    print(f"   ✓ 预估时间：{classification.estimated_time}秒")
    print(f"   ✓ 资源分配：{classification.resource_allocation}")
    
    print("\n" + "=" * 60)
    print("✅ 示例运行完成")
    print("=" * 60)
    print("\n💡 提示:")
    print("   • Context 监控：自动检测 Context 使用率")
    print("   • 子任务管理：并发控制和超时保护")
    print("   • Cron 超时：定时任务超时保护")
    print("   • 任务分类：智能资源分配")

if __name__ == '__main__':
    main()
