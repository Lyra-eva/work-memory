#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Stability System - 基础测试
"""

import sys
import os

# 添加核心模块到路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'core'))

def test_imports():
    """测试模块导入"""
    print("\n[1] 测试模块导入")
    try:
        from stability import (
            ContextMonitor,
            SubagentManager,
            CronTimeoutExecutor,
            TaskClassifier,
            HealthMonitor,
            PerformanceOptimizer
        )
        print("   ✅ 所有模块导入成功")
        return True
    except Exception as e:
        print(f"   ❌ 模块导入失败：{e}")
        return False

def test_context_monitor():
    """测试 Context 监控"""
    print("\n[2] 测试 ContextMonitor")
    try:
        from stability import ContextMonitor
        
        monitor = ContextMonitor()
        status = monitor.get_status()
        usage = monitor.check_usage()
        
        print(f"   ✅ ContextMonitor 初始化成功")
        print(f"      最大 tokens: {status['max_tokens']:,}")
        print(f"      当前会话：{usage['sessions']} 个")
        return True
    except Exception as e:
        print(f"   ❌ ContextMonitor 测试失败：{e}")
        return False

def test_subagent_manager():
    """测试子任务管理"""
    print("\n[3] 测试 SubagentManager")
    try:
        from stability import SubagentManager
        from stability.subagent_manager import TaskStatus
        
        manager = SubagentManager(max_concurrent=5)
        
        # 创建任务
        task = manager.create_task("test_task", timeout_seconds=30)
        manager.start_task(task.task_id)
        manager.complete_task(task.task_id, {"result": "success"})
        
        stats = manager.get_stats()
        print(f"   ✅ SubagentManager 测试成功")
        print(f"      总任务：{stats['total']} 个")
        print(f"      已完成：{stats['completed']} 个")
        return True
    except Exception as e:
        print(f"   ❌ SubagentManager 测试失败：{e}")
        return False

def test_cron_executor():
    """测试 Cron 执行器"""
    print("\n[4] 测试 CronTimeoutExecutor")
    try:
        from stability import CronTimeoutExecutor
        
        cron = CronTimeoutExecutor()
        
        # 添加任务
        task = cron.add_task("test_cron", "*/5 * * * *", timeout_seconds=10)
        
        # 执行任务
        def simple_task():
            return {"success": True}
        
        result = cron.execute_with_timeout(task.task_id, simple_task)
        stats = cron.get_stats()
        
        print(f"   ✅ CronTimeoutExecutor 测试成功")
        print(f"      总任务：{stats['total']} 个")
        print(f"      已完成：{stats['completed']} 个")
        return True
    except Exception as e:
        print(f"   ❌ CronTimeoutExecutor 测试失败：{e}")
        return False

def test_task_classifier():
    """测试任务分类器"""
    print("\n[5] 测试 TaskClassifier")
    try:
        from stability import TaskClassifier
        
        classifier = TaskClassifier()
        
        # 分类任务
        classification = classifier.classify(
            "web_search",
            "Search for information online"
        )
        
        print(f"   ✅ TaskClassifier 测试成功")
        print(f"      类型：{classification.task_type.value}")
        print(f"      优先级：{classification.priority}")
        print(f"      预估时间：{classification.estimated_time}秒")
        return True
    except Exception as e:
        print(f"   ❌ TaskClassifier 测试失败：{e}")
        return False

def test_health_monitor():
    """测试健康监控"""
    print("\n[6] 测试 HealthMonitor")
    try:
        from stability import HealthMonitor
        
        health = HealthMonitor()
        
        # 注册健康检查
        health.register_check("test", lambda: {"status": "healthy"})
        status = health.get_status()
        
        print(f"   ✅ HealthMonitor 测试成功")
        print(f"      整体状态：{status['overall']}")
        return True
    except Exception as e:
        print(f"   ❌ HealthMonitor 测试失败：{e}")
        return False

def main():
    """运行所有测试"""
    print("=" * 60)
    print("🛡️ Stability System - 安装验证测试")
    print("=" * 60)
    
    tests = [
        test_imports,
        test_context_monitor,
        test_subagent_manager,
        test_cron_executor,
        test_task_classifier,
        test_health_monitor,
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            if test():
                passed += 1
            else:
                failed += 1
        except Exception as e:
            print(f"   ❌ 测试异常：{e}")
            failed += 1
    
    print("\n" + "=" * 60)
    print(f"测试结果：{passed} 通过，{failed} 失败")
    print("=" * 60)
    
    if failed == 0:
        print("\n✅ 所有测试通过！安装成功！")
        return 0
    else:
        print(f"\n❌ {failed} 个测试失败")
        return 1

if __name__ == '__main__':
    sys.exit(main())
