#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Stability System for OpenClaw - 安装配置
"""

from setuptools import setup, find_packages
from pathlib import Path

# 读取 README
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text(encoding='utf-8')

# 读取依赖
requirements = []
if (this_directory / "requirements.txt").exists():
    with open(this_directory / "requirements.txt", 'r', encoding='utf-8') as f:
        requirements = [line.strip() for line in f if line.strip() and not line.startswith('#')]

setup(
    name='stability-system',
    version='1.0.0',
    author='OpenClaw Community',
    author_email='support@openclaw.ai',
    description='🛡️ 系统稳定性监控 - Context 监控、超时保护、熔断器',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/openclaw/stability-system',
    packages=find_packages(where='core'),
    package_dir={'': 'core'},
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
    ],
    python_requires='>=3.6',
    install_requires=requirements,
    entry_points={
        'console_scripts': [
            'stability-check=scripts.install:check_installation',
        ],
    },
    include_package_data=True,
    zip_safe=False,
)
